<img src="https://zanewesley.github.io/images/github-header.png" width="100%">

# Hey There!
I'm **Zane Wesley!** I love Jesus, web coding, running and Apple. I specialize in UX and UI development and design and work hard to make sure that all of my projects work flawlessly and are fully accessible.

Want to see what I've been up to? Visit my website to see my projects. [https://zanewesley.github.io](https://zanewesley.github.io)

Have feedback or want to get to know me?  [Contact me!](https://zanewesley.github.io/feedback)

## What's New
- 2023 Spring Update
- ZaneWesley Discord Server! [Join Here](https://discord.gg/4XEWxQ9Yvn)
- Tower Takedown (Tower Crash 3D Remake)
- Guess That Number 2
- Corey 3.0 Release

## What I'm Working On
- FLIP memory game
- Tower Defence Game
- Piano Tiles 2/Perfect Piano Remake
- 3d Web platformer game
- Group messaging webapp


## Stats
[![Zane's Stats](https://github-readme-stats.vercel.app/api?username=zanewesley&layout=compact&hide=prs&show_icons=true)](https://github.com/zanewesley)

## Languages
![html5](https://img.shields.io/badge/html5-f06529?&style=for-the-badge&logo=html5&logoColor=f06529&colorA=eeeeee&colorB=f06529)
![markdown](https://img.shields.io/badge/markdown-0077b5?style=for-the-badge&logo=markdown&logoColor=444444&colorA=eeeeee&colorB=444444)
![css3](https://img.shields.io/badge/css3-2965f1?&style=for-the-badge&logo=css3&logoColor=2965f1&colorA=eeeeee&colorB=2965f1)
![Scss](https://img.shields.io/badge/sass-cd6799?&style=for-the-badge&logo=sass&logoColor=cd6799&colorA=eeeeee&colorB=cd6799)
![javaScript](https://img.shields.io/badge/javascript-f0db4f?&style=for-the-badge&logo=javascript&logoColor=323330&colorA=eeeeee&colorB=f0db4f)

## Socials
<a href="https://codepen.io/zanewesley">CodePen</a>
<br>
<a href="https://www.strava.com/athletes/83598166">Strava</a>
<br>
<a href="https://discord.gg/4XEWxQ9Yvn">Discord</a>
