ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1462688.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 91726623, 91726657, 91726620, 91726622, 91726621, 91726619, 91726626, 91726653, 91726631, 91726628, 91726630, 91726629, 91726663, 91726601, 91726655, 91726664 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
